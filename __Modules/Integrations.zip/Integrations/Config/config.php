<?php

return [
    'name' => 'Integrations'
];
