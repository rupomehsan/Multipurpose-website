<?php

return [
    'name' => 'HotelBooking'
];
